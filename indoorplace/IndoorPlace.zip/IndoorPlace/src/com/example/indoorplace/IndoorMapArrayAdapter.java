package com.example.indoorplace;

public class IndoorMapArrayAdapter {

	public static String getOriginalCurTouchCoords() {
		// TODO Auto-generated method stub
		return null;
	}

}
