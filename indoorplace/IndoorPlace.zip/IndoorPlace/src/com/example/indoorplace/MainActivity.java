package com.example.indoorplace;

import android.app.Activity;
import android.os.Bundle;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import android.net.wifi.WifiManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;

import com.example.indoorplace.R;
import com.example.indoorplace.MainActivity;
import com.example.indoorplace.ObtainRssData;
import com.example.indoorplace.FileOperation;
import com.example.indoorplace.SocketClient;
	 
	public class MainActivity extends Activity {
		WifiManager wifiMg;
		ProgressBar myProBar;
		ObtainRssData obtainRssData;
		int acquireSignalTotalNum     = 20;
		long acquireTimeInterval_ms   = 1000;
		Timer timerShow               = null;
		TimerTask taskShow            = null;
		String rssFile                = "/1Rss/rss.txt";
		
		final long updateItemMilliTime              = 40;
		final long backSpaceTimeIntervalMilliSecond = 1000;
		Button 	ScanData, SeeData, SentData,StopSent;
		@Override
		protected void onCreate(Bundle savedInstanceState) {	
			setTheme(R.style.AppTheme);
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			wifiMg = (WifiManager)getSystemService(WIFI_SERVICE);
			obtainRssData = new ObtainRssData(wifiMg, MainActivity.this);
			myProBar = (ProgressBar) findViewById(R.id.progressBar_obtainRss);
			
			ScanData = (Button) findViewById(R.id.button1);
			SeeData = (Button) findViewById(R.id.button2);
			SentData = (Button) findViewById(R.id.button3);
			StopSent = (Button) findViewById(R.id.button4);
		
			ScanData.setOnClickListener(new Button.OnClickListener()
			{
				@Override
				public void onClick(View v) {
				openWifi();
				obtainRssData.obtainRssData(myProBar, obtainRssData, rssFile);
				try {
					FileOperation.saveToFile(ObtainRssData.getOnLineRssAndCoordinateData(), rssFile);
				} 
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}	
			}
			);
			SeeData.setOnClickListener(new Button.OnClickListener()
			{

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					FileOperation.openFile(MainActivity.this, rssFile);
				}	
			}
			);
			SentData.setOnClickListener(new Button.OnClickListener()
			{

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					SocketClient.connectServer(MainActivity.this);
					
				}	
			}
			);
			StopSent.setOnClickListener(new Button.OnClickListener()
			{

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					SocketClient.disconnectServer();
				}
				
			});
		};
		
		public void openWifi() {
	        if(!wifiMg.isWifiEnabled())
	        {  
	        	wifiMg.setWifiEnabled(true); 
	        }  
	    } 
		
		@Override
		protected void onDestroy() {
			
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
			super.onDestroy();
		}
		
	}
